'use strict';

jQuery(document).ready(function($){

  if($.fn.zoomBox){
    $(".zoombox").zoomBox();
  }
})