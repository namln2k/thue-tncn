<?php

return json_decode(dzs_read_from_file_ob(DZSAP_BASE_PATH . 'configs/config-gutenberg-player.json'), true);